/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package codigo;

import java.util.Properties;
import java.io.IOException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.SwingUtilities;

/**
 *
 * @author Admin
 */
public class Emulador {

        public static Properties configuracion = new Properties();

    
    public static void main(String[] args) {
        //SwingUtilities.invokeLater(() -> { //se utiliza para crear y mostrar la ventana del juego en el hilo 
            //de eventos de Swing de una manera segura y adecuada.
            //Juego juego = new Juego();
            //try {
                //Juego.crearProperties(System.getProperty("user.home") + "/.proyecto/proyecto.conf");
            //} catch (IOException ex) {
                //Logger.getLogger(Emulador.class.getName()).log(Level.SEVERE, null, ex);
            //}
            //juego.setVisible(true);
        //});
    }
}
