\echo ---------- taula logro

CREATE TABLE logro (
	nom TEXT PRIMARY KEY,
	descripcio TEXT,
	data DATE
);