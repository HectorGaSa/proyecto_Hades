\echo ---------- taula usuario

CREATE TABLE usuario (
	nom_usuari TEXT PRIMARY KEY,
	nom TEXT,
	cognom1 TEXT,
	cognom2 TEXT,
	contrasenya TEXT,
	correu TEXT,
	telefon TEXT,
	tipus TEXT CHECK (tipus IN ('jugador', 'admin', 'superadmin'))
);