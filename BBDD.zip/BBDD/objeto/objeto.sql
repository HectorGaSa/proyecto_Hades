\echo ---------- taula objeto

CREATE TABLE objeto (
	nom TEXT PRIMARY KEY,
	tipus TEXT,
	descripcio TEXT,
	valor INTEGER,
	durabilitat FLOAT,
	pool TEXT

);